// generated from rosidl_generator_c/resource/idl.h.em
// with input from micro_ros_msgs:msg/Entity.idl
// generated code does not contain a copyright notice

#ifndef MICRO_ROS_MSGS__MSG__ENTITY_H_
#define MICRO_ROS_MSGS__MSG__ENTITY_H_

#include "micro_ros_msgs/msg/detail/entity__struct.h"
#include "micro_ros_msgs/msg/detail/entity__functions.h"
#include "micro_ros_msgs/msg/detail/entity__type_support.h"

#endif  // MICRO_ROS_MSGS__MSG__ENTITY_H_
